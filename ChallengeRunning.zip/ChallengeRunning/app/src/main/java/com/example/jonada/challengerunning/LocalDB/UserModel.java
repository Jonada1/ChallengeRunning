package com.example.jonada.challengerunning.LocalDB;

public class UserModel {

    public int id;
    public String name,email,password;
}
